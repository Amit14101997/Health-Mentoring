package com.example.helthmentoring;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class BookApoinmentActivity extends AppCompatActivity {
    EditText edt1,edt2,edt3,edt4;
    TextView tv,textDate,textTime;
    Button bookAppoinment,back;
   private DatePickerDialog datePickerDialog;
    private TimePickerDialog timePickerDialog;
    private Button dateButton,timeButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_apoinment);

        tv=findViewById(R.id.textViewAppTitle);
        edt1=findViewById(R.id.editTextAppFullName);
        edt2=findViewById(R.id.editTextAppAdress);
        edt3=findViewById(R.id.editTextAppContactNo);
        edt4=findViewById(R.id.editTextAppFess);
       dateButton=findViewById(R.id.buttonAppDate);
      timeButton=findViewById(R.id.buttonAppTime);
      textDate=findViewById(R.id.textDatePick);
      textTime=findViewById(R.id.textTimePick);
      bookAppoinment=findViewById(R.id.ButtonBookAppoinment);
      back=findViewById(R.id.BookAppBack);


        edt1.setKeyListener(null);
        edt2.setKeyListener(null);
        edt3.setKeyListener(null);
        edt4.setKeyListener(null);

        Intent it=getIntent();
        String title=it.getStringExtra("text1");
        String fullname=it.getStringExtra("text2");
        String address=it.getStringExtra("text3");
        String contact=it.getStringExtra("text4");
        String fees=it.getStringExtra("text5");

        tv.setText(title);
        edt1.setText(fullname);
        edt2.setText(address);
        edt3.setText(contact);
        edt4.setText("Cons Fees:"+fees+"/-");

        // initDatePicker();
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initDatePicker();
            }
        });

        // initTimePicker();
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initTimePicker();
            }
        });

        bookAppoinment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences sharedPreferences=getSharedPreferences("shared_pref", Context.MODE_PRIVATE);
                String username=sharedPreferences.getString("username","").toString();
                Database db=new Database(getApplicationContext(),"healthmentoring",null,1);

                if(db.checkAppointmentExist(username,title+"=>"+fullname,address,contact,textDate.getText().toString(),textTime.getText().toString())==1){
                    Toast.makeText(getApplicationContext(), "Appoinment already booked", Toast.LENGTH_SHORT).show();
                }else{
                    db.addOrder(username,title+"=>"+fullname,address,contact,0,textDate.getText().toString(),textTime.getText().toString(),Float.parseFloat(fees),"appoinment");
                    Toast.makeText(getApplicationContext(), "Your Appoinment is done Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(BookApoinmentActivity.this,HomeActivity.class));
                }


            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BookApoinmentActivity.this,FindDocActivity.class));
            }
        });
    }


    Calendar cal=Calendar.getInstance();
   private void initDatePicker(){
        DatePickerDialog dialog=new DatePickerDialog(this,R.style.DialogTheme, new DatePickerDialog.OnDateSetListener() {


            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                textDate.setText(String.valueOf(year)+"/"+String.valueOf(month+1)+"/"+String.valueOf(day));
            }
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        dialog.show();
   }

   private void initTimePicker(){
       TimePickerDialog dialogtime=new TimePickerDialog(this,R.style.DialogTheme, new TimePickerDialog.OnTimeSetListener() {
           @Override
           public void onTimeSet(TimePicker timePicker, int hours, int minutes) {
               textTime.setText(String.valueOf(hours)+":"+String.valueOf(minutes));
           }
       }, cal.get(Calendar.HOUR), cal.get(Calendar.MINUTE), true);
       dialogtime.show();
   }







    }
