package com.example.helthmentoring;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class DocDetailsActivity extends AppCompatActivity {

    private String[][] doctor_details1={
            {"Doctor Name:Amit Sarkar","Hospital Address:Jadavpur,Kolkata","Exp:5yrs","Mobile No:9825647822","500"},
            {"Doctor Name:Suparna Mondal","Hospital Address:Garia,Kolkata","Exp:10yrs","Mobile No:9825644788","1500"},
            {"Doctor Name:Ayan Das","Hospital Address:Medical Clg,Kolkata","Exp:15yrs","Mobile No:9825647863","700"},
            {"Doctor Name:Priyanka Dey","Hospital Address:Mandirtola,Howrah","Exp:7yrs","Mobile No:7215647822","600"}
    };

    private String[][] doctor_details2={
            {"Doctor Name:Ayan Mondal","Hospital Address:Jadavpur,Kolkata","Exp:5yrs","Mobile No:9825647822","500"},
            {"Doctor Name:Suparna Mondal","Hospital Address:Garia,Kolkata","Exp:10yrs","Mobile No:9825644788","1500"},
            {"Doctor Name:Ayan Das","Hospital Address:Medical Clg,Kolkata","Exp:15yrs","Mobile No:9825647863","700"},
            {"Doctor Name:Priyanka Dey","Hospital Address:Mandirtola,Howrah","Exp:7yrs","Mobile No:7215647822","600"}
    };

    private String[][] doctor_details3={
            {"Doctor Name:Amit Sarkar","Hospital Address:Jadavpur,Kolkata","Exp:5yrs","Mobile No:9825647822","500"},
            {"Doctor Name:Suparna Mondal","Hospital Address:Garia,Kolkata","Exp:10yrs","Mobile No:9825644788","1500"},
            {"Doctor Name:Ayan Das","Hospital Address:Medical Clg,Kolkata","Exp:15yrs","Mobile No:9825647863","700"},
            {"Doctor Name:Priyanka Dey","Hospital Address:Mandirtola,Howrah","Exp:7yrs","Mobile No:7215647822","600"}
    };

    private String[][] doctor_details4={
            {"Doctor Name:Amit Sarkar","Hospital Address:Jadavpur,Kolkata","Exp:5yrs","Mobile No:9825647822","500"},
            {"Doctor Name:Suparna Mondal","Hospital Address:Garia,Kolkata","Exp:10yrs","Mobile No:9825644788","1500"},
            {"Doctor Name:Ayan Das","Hospital Address:Medical Clg,Kolkata","Exp:15yrs","Mobile No:9825647863","700"},
            {"Doctor Name:Priyanka Dey","Hospital Address:Mandirtola,Howrah","Exp:7yrs","Mobile No:7215647822","600"}
    };

    private String[][] doctor_details5={
            {"Doctor Name:Amit Sarkar","Hospital Address:Jadavpur,Kolkata","Exp:5yrs","Mobile No:9825647822","500"},
            {"Doctor Name:Suparna Mondal","Hospital Address:Garia,Kolkata","Exp:10yrs","Mobile No:9825644788","1500"},
            {"Doctor Name:Ayan Das","Hospital Address:Medical Clg,Kolkata","Exp:15yrs","Mobile No:9825647863","700"},
            {"Doctor Name:Priyanka Dey","Hospital Address:Mandirtola,Howrah","Exp:7yrs","Mobile No:7215647822","600"}
    };
    TextView tv;
    Button btn;
    ArrayList list;
    SimpleAdapter sa;
    HashMap<String,String> item;

    String[][] doctor_details={};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_details);
        tv=findViewById(R.id.textViewDDtitle);
        btn=findViewById(R.id.buttonLTBack);
        Intent it=getIntent();
        String title=it.getStringExtra("title");
        tv.setText(title);

        if (title.compareTo("Family Physicians")==0)
            doctor_details=doctor_details1;
        else
        if (title.compareTo("Dieticians")==0)
            doctor_details=doctor_details2;
        else
        if (title.compareTo("Dentists")==0)
            doctor_details=doctor_details3;
        else
        if (title.compareTo("Surgeons")==0)
            doctor_details=doctor_details4;
        else
            doctor_details=doctor_details5;


            btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DocDetailsActivity.this,FindDocActivity.class));
            }
        });

        list=new ArrayList();
        for (int i=0;i<doctor_details.length;i++){
            item=new HashMap<String,String>();
            item.put("line1",doctor_details[i][0]);
            item.put("line2",doctor_details[i][1]);
            item.put("line3",doctor_details[i][2]);
            item.put("line4",doctor_details[i][3]);
            item.put("line5","Cons Fees:"+doctor_details[i][4]+"/-");
            list.add(item);
        }
        sa=new SimpleAdapter(this,list,
                R.layout.multi_line,new String[]{"line1","line2","line3","line4","line5"},
                new int[]{R.id.line_a,R.id.line_b,R.id.line_c,R.id.line_d,R.id.line_e});
        ListView lst=findViewById(R.id.listViewLT);
        lst.setAdapter(sa);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener(){

           @Override
           public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            Intent it=new Intent(DocDetailsActivity.this,BookApoinmentActivity.class);
               it.putExtra("text1",title);
               it.putExtra("text2",doctor_details[i][0]);
               it.putExtra("text3",doctor_details[i][1]);
               it.putExtra("text4",doctor_details[i][3]);
               it.putExtra("text5",doctor_details[i][4]);
            startActivity(it);
           }
       });
    }
}