package com.example.helthmentoring;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {


    EditText edusername,edemail,edpassword,edconfpassword;
    Button btn;
    TextView txt,txt1,txt2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        txt1=(TextView) findViewById(R.id.textView6);
        txt1.setTextColor(getResources().getColor(R.color.white));
        txt2=(TextView) findViewById(R.id.textViewAppTitle);
        txt2.setTextColor(getResources().getColor(R.color.white));

        edconfpassword=(EditText) findViewById(R.id.editTextAppFess);
        edemail=(EditText) findViewById(R.id.editTextAppAdress);
        edpassword=(EditText) findViewById(R.id.editTextAppContactNo);
        edusername=(EditText) findViewById(R.id.editTextAppFullName);
        btn=(Button) findViewById(R.id.ButtonBookAppoinment);

        txt=(TextView) findViewById(R.id.textView8);
        txt.setTextColor(getResources().getColor(R.color.white));

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username=edusername.getText().toString();
                String email=edemail.getText().toString();
                String password=edpassword.getText().toString();
                String confPassword=edconfpassword.getText().toString();
                Database db=new Database(getApplicationContext(),"healthmentoring",null,1);


                if(username.length()==0||password.length()==0||email.length()==0||confPassword.length()==0){
                    Toast.makeText(getApplicationContext(),"Please fill All details",Toast.LENGTH_SHORT).show();
                 }else{
                    if(password.compareTo(confPassword)==0){
                        if(isValid(password)){
                            db.register(username,email,password);

                            Toast.makeText(getApplicationContext(),"Record Inserted",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
                        }else{
                            Toast.makeText(getApplicationContext(),"Password must contain at least 8 characters,having letter,digit and ",Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(),"Password and confirm password didn't match",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        }

        public static boolean isValid(String ps){
           int f1=0,f2=0,f3=0;
           if(ps.length()<8){
            return false;
            }else{
               for (int p=0;p<ps.length();p++){
                if(Character.isLetter((ps.charAt(p)))){
                    f1=1;
                }
               }
               for (int r=0;r<ps.length();r++){
                   if(Character.isLetter((ps.charAt(r)))){
                       f2=1;
                   }
               }
               for (int s=0;s<ps.length();s++){
                   char  c=ps.charAt(s);
                   if(c>=33&&c<=46||c==64){
                       f3=1;
                   }
               }
               if( f1==1&& f2==1 &&f3==1){
                   return true;
               }
               return false;
           }
        }
}